package com.movierental;

import org.junit.Test;

public class CustomerTest {
    @Test
    public void test(){}

}